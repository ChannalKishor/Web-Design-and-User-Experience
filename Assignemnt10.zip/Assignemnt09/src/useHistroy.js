import { useState } from "react";
import { useHistory } from "react-router-dom";

export function useHistoryState(key, initialValue) {
  const history = useHistory();
  const [rawState, rawSetState] = useState(() => {
    const value = history.location.state?.[key] ?? initialValue;
    return value;
  });
  function setState(value) {
    history.replaceState({
      ...history.location,
      state: {
        ...history.location.state,
        [key]: value,
      },
    });
    rawSetState(value);
  }
  return [rawState, setState];
}
