import React from "react";
import { Link } from "react-router-dom";
import { withRouter } from "react-router-dom";

import moment from "moment";

function WeatherData({
  reading: { dt, day, weather, main },
  completeData,
  cityName,
}) {
  const _date = new Date(dt * 1000);

  const _img = `owf owf-${weather[0].id} owf-5x`;

  return (
    <Link
      to={{
        pathname: `/hourlyForecast/${day}`,
        state: {
          completeData,
          cityName,
        },
      }}
    >
      <div className="card py-2 mt-3">
        <h4 className="text-secondary">
          {moment(_date).format("MMMM D YYYY")}
        </h4>
        <h5>{day}</h5>
        <i className={_img}></i>
        <p>{weather[0].description}</p>
        <h5>Temperature: {main.temp}°F</h5>
        <p>
          Minimum: {main.temp_min}°F and Maximum: {main.temp_max}°F
        </p>
      </div>
    </Link>
  );
}

export default WeatherData;
