import React from "react";
import moment from "moment";

const HourlyCityForecast = ({ data }) => {
  const { dt, main, weather, day } = data;
  const date = new Date(dt * 1000);
  const imgClass = `owf owf-${weather[0].id} owf-5x`;
  const fahrenheitMax = Math.round(main.temp_max);
  const fahrenheitMin = Math.round(main.temp_min);
  const farenheitTemp = Math.round(main.temp);

  return (
    <div className="row">
      <div className="col-12">
        <div className="card py-2 my-3">
          <div className="row">
            <div className="col">
              <h4 className="text-muted">
                {moment(date).format("MMMM D YYYY")}
              </h4>
              <h5>
                {day} at {moment(date).format("HH:mm a")}
              </h5>
              <i className={imgClass}></i>
              <p>{weather[0].description}</p>
              <h5>Temperature: {farenheitTemp}°F</h5>
              <p>
                Minimum: {fahrenheitMin}°F and Maximum: {fahrenheitMax}°F
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HourlyCityForecast;
