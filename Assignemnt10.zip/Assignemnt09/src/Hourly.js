import React, { useState, useEffect } from "react";
import HourlyCityForecast from "./HourlyCityForecast";

function Hourly(props) {
  const completeData = props.location.state.completeData;
  const selectedParam = props.match.params;

  const [data, setData] = useState([]);

  useEffect(() => {
    const tempData = completeData.filter((cd) => cd.day === selectedParam.day);
    setData(tempData);
  }, [completeData, selectedParam.day]);

  console.log(props, data);

  return (
    <div className="container">
      <h4 className="py-3">
        {" "}
        {props.location.state.cityName} {selectedParam.day} Report
      </h4>
      <div className="justify-content-center m-2">
        {data.map((value, index) => (
          <HourlyCityForecast data={value} key={index} />
        ))}
      </div>
    </div>
  );
}

export default Hourly;
