import React from "react";
import { render, fireEvent } from "@testing-library/react";
import App from "./App";

test('renders App component with "learn react" text', () => {
  const { getByText } = render(<App />);
  const linkElement = getByText(/learn react/i);
  expect(linkElement).toBeInTheDocument();

  // Simulate a button click and check if the expected action was performed
  const buttonElement = getByText(/click me/i);
  fireEvent.click(buttonElement);
  const messageElement = getByText(/button clicked/i);
  expect(messageElement).toBeInTheDocument();
});
